Convert fryingfood to mono and obtain a clip starting from 10.640s, name it food.wav
Run food.py and obtain food.loop.wav and food.loop.intro.wav

Cut alarm to clips ding.wav and ring.intro.wav
Analyze and transform ring.intro.wav with HPS model and obtain ring.intro.t.wav

```python
window='blackman', M=401, N=2048, t=-120
minSineDur=0.001, nH=100, minf0=700, maxf0=900
f0et=10, harmDevSlope=1, stocf=0.1

freqScaling=[0, 2, 0.8, 1, 2.5, 1]
freqStretching=[0, 1.2, 0.6, 1.05, 1.2, 1, 2.5, 1]
timbrePreservation=0
timeScaling=[0, 0, 1, 1.5, 2.5, 3]
```

Cut plates to obtain plates.[on|off]beat.[1-3].wav and plates.bridge.wav
Cut caffettiera and apply fade-in and fade-out (each sustaining half of the clip) to obtain boil.wav
Cut caffettiera to boil.short.wav

Analyze and transform boil.short.wav and ring.intro.wav with STFT Morph model and obtain boil.short.m.wav

```python
window1='hamming', M1=1024, N1=1024, H1=256
window2='hamming', M2=1024, N2=1024
smoothFactor=0.01
balanceFactor=0.7
```

Cut microwave to microwave.wav
Mix the sounds in LMMS
