import os
import sys

import numpy as np

sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../software/models/'))
import utilFunctions as UF

fs, x = UF.wavread('food.wav')

bpm = 92

sq = 60.0 / bpm / 4
loop_size = int(32 * sq * fs)

def create_loopline(notes, path):
    print(notes)
    y = np.array([0.0] * int(len(notes) * sq * fs))

    for i in range(len(notes)):
        fac = (1.0 if notes[i] == 'o' else 0.4)
        if i % 8 == 0: fac *= 1.5
        for j in range(int(i * sq * fs), int((i + 0.8) * sq * fs)):
            y[j] = x[j % loop_size] * fac
        for j in range(int((i + 0.8) * sq * fs), int((i + 0.85) * sq * fs)):
            y[j] = x[j % loop_size] * fac * 0.5
        for j in range(int((i + 0.85) * sq * fs), int((i + 1) * sq * fs)):
            y[j] = x[j % loop_size] * fac * 0.2

    print(len(y), len(y) / fs)
    UF.wavwrite(y, fs, path)

bar_template = 'o..o..o..o..'
bars = ['..o.', '.o..', '.oo.', 'o...', 'o.o.', 'oo..', 'ooo.', 'oo.o']

notes = ''.join([(bar_template + bars[i]) for i in range(len(bars))])
create_loopline(notes, 'food.loop.wav')

notes = 'o..' * 5 + '.' + 'o..' * 3
create_loopline(notes, 'food.loop.intro.wav')
