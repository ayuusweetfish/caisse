#include <stm32f1xx_hal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

SPI_HandleTypeDef spi1 = { 0 };
DMA_HandleTypeDef dma_spi_tx, dma_spi_rx;
TIM_HandleTypeDef tim2;
TIM_HandleTypeDef tim3;

#define WRITE_FLASH 0

#define LED_PORT    GPIOA
#define LED_PIN_ACT GPIO_PIN_0

#define USE_HSE 1
#if USE_HSE
  #define CYC_MICROSECOND 72
#else
  #define CYC_MICROSECOND 64
#endif

#define FLASH_CS_PORT GPIOA
#define FLASH_CS_PIN  GPIO_PIN_3
#define DAC_CS_PORT   GPIOA
#define DAC_CS_PIN    GPIO_PIN_4
#define AMP_SHDN_PORT GPIOA
#define AMP_SHDN_PIN  GPIO_PIN_2

#include "base.h"

static struct sampler_t sampler = { 0 };
static volatile int16_t sample_output = 0;

#define min(_a, _b) ((_a) < (_b) ? (_a) : (_b))
#define max(_a, _b) ((_a) > (_b) ? (_a) : (_b))

struct debouncer {
  int32_t mul;
  int32_t high, highhigh;
  int32_t threshold;
  int8_t count;
  bool on;
};

static inline void debouncer_init(struct debouncer *d)
{
  d->high = -1;
  d->on = false;
}

static inline void debouncer_update(struct debouncer *d, int32_t value)
{
  if (d->high < 0) {
    d->high = value - 80 * d->mul;
    d->highhigh = value - 80 * d->mul;
  }

  d->high = max(d->high - 64 * d->mul, min(d->high + 256 * d->mul, value));
  d->highhigh = max(d->highhigh - 1 * d->mul, min(d->highhigh + 6 * d->mul, d->high));
}

// Returns whether state changed
static inline bool debouncer_state_switch(struct debouncer *d)
{
  if (!d->on && d->high <= d->highhigh - d->threshold) {
    d->on = true;
    return true;
  }
  if (d->on && d->high > d->highhigh - d->threshold / 2) {
    d->on = false;
    return true;
  }
  return false;
}

static inline int32_t debouncer_intensity(const struct debouncer *d)
{
  return d->highhigh - d->high;
}

int main()
{
  HAL_Init();

  // ======== GPIO ========
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  GPIO_InitTypeDef gpio_init;

  gpio_init.Pin = LED_PIN_ACT;
  gpio_init.Mode = GPIO_MODE_OUTPUT_PP;
  gpio_init.Pull = GPIO_PULLUP;
  gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(LED_PORT, &gpio_init);
  HAL_GPIO_WritePin(LED_PORT, LED_PIN_ACT, GPIO_PIN_RESET);

  // Clocks
  RCC_OscInitTypeDef rcc_osc_init = { 0 };
#if USE_HSE
  rcc_osc_init.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  rcc_osc_init.HSEState = RCC_HSE_ON;
  rcc_osc_init.PLL.PLLState = RCC_PLL_ON;
  rcc_osc_init.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  rcc_osc_init.PLL.PLLMUL = RCC_PLL_MUL6;
#else
  rcc_osc_init.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  rcc_osc_init.HSIState = RCC_HSI_ON;
  rcc_osc_init.PLL.PLLState = RCC_PLL_ON;
  rcc_osc_init.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  rcc_osc_init.PLL.PLLMUL = RCC_PLL_MUL16;
#endif
  HAL_RCC_OscConfig(&rcc_osc_init);

  RCC_ClkInitTypeDef rcc_clk_init = { 0 };
  rcc_clk_init.ClockType =
    RCC_CLOCKTYPE_SYSCLK |
    RCC_CLOCKTYPE_HCLK |
    RCC_CLOCKTYPE_PCLK1 |
    RCC_CLOCKTYPE_PCLK2;
  rcc_clk_init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  rcc_clk_init.AHBCLKDivider = RCC_SYSCLK_DIV1;
  rcc_clk_init.APB1CLKDivider = RCC_HCLK_DIV2;
  rcc_clk_init.APB2CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&rcc_clk_init, FLASH_LATENCY_2);

  CoreDebug->DEMCR &= ~CoreDebug_DEMCR_TRCENA_Msk;
  CoreDebug->DEMCR |=  CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CTRL &= ~DWT_CTRL_CYCCNTENA_Msk;
  DWT->CTRL |=  DWT_CTRL_CYCCNTENA_Msk;
  DWT->CYCCNT = 0;

  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);

  swv_printf("HCLK freq = %u\n", HAL_RCC_GetHCLKFreq());

  uint32_t unique_id[3] = {
    *(uint32_t *)(0x1FFFF7E8 + 0x0),
    *(uint32_t *)(0x1FFFF7E8 + 0x4),
    *(uint32_t *)(0x1FFFF7E8 + 0x8),
  };
  swv_printf("Unique ID = %08x %08x %08x\n", unique_id[0], unique_id[1], unique_id[2]);
  // 0: 05d5ff36 3330434d 43106943
  // 1: 05ddff34 3237484b 43234926

  for (int i = 0; i < 2; i++) {
    HAL_GPIO_WritePin(LED_PORT, LED_PIN_ACT, GPIO_PIN_RESET);
    HAL_Delay(100);
    HAL_GPIO_WritePin(LED_PORT, LED_PIN_ACT, GPIO_PIN_SET);
    HAL_Delay(100);
  }

  // ======== IWDG ========
  // LSI 32 kHz: (256 * 500) / 32 kHz = 4 s
  IWDG_HandleTypeDef iwdg = (IWDG_HandleTypeDef){
    .Instance = IWDG,
    .Init = {
      .Prescaler = IWDG_PRESCALER_256,
      .Reload = 500 - 1,
    },
  };
#if !defined(WRITE_FLASH) || WRITE_FLASH == 0
  HAL_IWDG_Init(&iwdg);
#endif

  // ======== Timer ========
  __HAL_RCC_TIM2_CLK_ENABLE();
  // APB1 = HCLK / 2 = 36 MHz
  // 72 MHz / 300 / 10 = 24 kHz
  tim2 = (TIM_HandleTypeDef){
    .Instance = TIM2,
    .Init = {
      .Prescaler = 300 - 1,
      .CounterMode = TIM_COUNTERMODE_UP,
      .Period = 10 - 1,
      .ClockDivision = TIM_CLOCKDIVISION_DIV1,
      .RepetitionCounter = 0,
    },
  };
  HAL_TIM_Base_Init(&tim2);
  HAL_TIM_Base_Start_IT(&tim2);
  __HAL_TIM_ENABLE_IT(&tim2, TIM_IT_UPDATE);
  HAL_NVIC_SetPriority(TIM2_IRQn, 3, 0);

  __HAL_RCC_TIM3_CLK_ENABLE();
  // 72 MHz / 6000 / 10 = 1200 Hz
  tim3 = (TIM_HandleTypeDef){
    .Instance = TIM3,
    .Init = {
      .Prescaler = 6000 - 1,
      .CounterMode = TIM_COUNTERMODE_UP,
      .Period = 10 - 1,
      .ClockDivision = TIM_CLOCKDIVISION_DIV1,
      .RepetitionCounter = 0,
    },
  };
  HAL_TIM_Base_Init(&tim3);
  HAL_TIM_Base_Start_IT(&tim3);
  __HAL_TIM_ENABLE_IT(&tim3, TIM_IT_UPDATE);
  HAL_NVIC_SetPriority(TIM3_IRQn, 4, 0);

  // ======== Software I2C ========
  gpio_init.Pin = I2Cx_PIN_SCL | I2Cx_PIN_SDA_0 | I2Cx_PIN_SDA_1;
  gpio_init.Mode = GPIO_MODE_OUTPUT_OD;
  gpio_init.Pull = GPIO_PULLUP;
  gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(I2Cx_PORT, &gpio_init);
  i2c_init();

  // ======== DMA for SPI ========
  __HAL_RCC_DMA1_CLK_ENABLE();
  dma_spi_tx.Instance = DMA1_Channel3;
  dma_spi_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
  dma_spi_tx.Init.PeriphInc = DMA_PINC_DISABLE;
  dma_spi_tx.Init.MemInc = DMA_MINC_ENABLE;
  dma_spi_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
  dma_spi_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
  dma_spi_tx.Init.Mode = DMA_NORMAL;
  dma_spi_tx.Init.Priority = DMA_PRIORITY_LOW;
  HAL_DMA_Init(&dma_spi_tx);

  dma_spi_rx.Instance = DMA1_Channel2;
  dma_spi_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
  dma_spi_rx.Init.PeriphInc = DMA_PINC_DISABLE;
  dma_spi_rx.Init.MemInc = DMA_MINC_ENABLE;
  dma_spi_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
  dma_spi_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
  dma_spi_rx.Init.Mode = DMA_NORMAL;
  dma_spi_rx.Init.Priority = DMA_PRIORITY_LOW;
  HAL_DMA_Init(&dma_spi_rx);

  // ======== SPI ========
  // GPIO ports
  // SPI1_SCK (PA5), SPI1_MOSI (PA7)
  gpio_init.Pin = GPIO_PIN_5 | GPIO_PIN_7;
  gpio_init.Mode = GPIO_MODE_AF_PP;
  gpio_init.Pull = GPIO_PULLDOWN;
  gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &gpio_init);
  // SPI1_MISO (PA6)
  gpio_init.Pin = GPIO_PIN_6;
  gpio_init.Mode = GPIO_MODE_AF_PP;
  gpio_init.Pull = GPIO_NOPULL;
  gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &gpio_init);
  // SPI1_NSS (PA4 - DAC), extra NSS (PA3 - flash)
  gpio_init.Mode = GPIO_MODE_OUTPUT_PP;
  gpio_init.Pin = FLASH_CS_PIN;
  HAL_GPIO_Init(FLASH_CS_PORT, &gpio_init);
  HAL_GPIO_WritePin(FLASH_CS_PORT, FLASH_CS_PIN, GPIO_PIN_SET);
  gpio_init.Pin = DAC_CS_PIN;
  HAL_GPIO_Init(DAC_CS_PORT, &gpio_init);
  HAL_GPIO_WritePin(DAC_CS_PORT, DAC_CS_PIN, GPIO_PIN_SET);

  __HAL_RCC_SPI1_CLK_ENABLE();
  spi1.Instance = SPI1;
  spi1.Init.Mode = SPI_MODE_MASTER;
  spi1.Init.Direction = SPI_DIRECTION_2LINES;
  spi1.Init.CLKPolarity = SPI_POLARITY_LOW; // CPOL = 0
  spi1.Init.CLKPhase = SPI_PHASE_1EDGE;     // CPHA = 0
  spi1.Init.NSS = SPI_NSS_SOFT;
  spi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  spi1.Init.TIMode = SPI_TIMODE_DISABLE;
  spi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  // The following should be overridden by spi_for_flash() or spi_for_dac()
  spi1.Init.DataSize = SPI_DATASIZE_8BIT;
  spi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  __HAL_LINKDMA(&spi1, hdmatx, dma_spi_tx);
  __HAL_LINKDMA(&spi1, hdmarx, dma_spi_rx);
  HAL_SPI_Init(&spi1);
  __HAL_SPI_ENABLE(&spi1);

  // Enable DMA interrupts
  HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 2, 1);
  HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn);
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);
  HAL_NVIC_SetPriority(SPI1_IRQn, 2, 2);
  HAL_NVIC_EnableIRQ(SPI1_IRQn);

  __HAL_DMA_ENABLE_IT(&dma_spi_tx, (DMA_IT_TC | DMA_IT_TE));
  __HAL_DMA_ENABLE(&dma_spi_tx);
  __HAL_DMA_ENABLE_IT(&dma_spi_rx, (DMA_IT_TC | DMA_IT_TE));
  __HAL_DMA_ENABLE(&dma_spi_rx);

  // ======== Amplifier shutdown pin ========
  gpio_init.Pin = AMP_SHDN_PIN;
  gpio_init.Mode = GPIO_MODE_OUTPUT_PP;
  gpio_init.Pull = GPIO_PULLUP;
  gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(AMP_SHDN_PORT, &gpio_init);
  HAL_GPIO_WritePin(AMP_SHDN_PORT, AMP_SHDN_PIN, GPIO_PIN_SET);

  // Start audio
  HAL_NVIC_EnableIRQ(TIM2_IRQn);
  HAL_NVIC_EnableIRQ(TIM3_IRQn);

#if WRITE_FLASH
{
  HAL_NVIC_DisableIRQ(TIM2_IRQn);
  HAL_NVIC_DisableIRQ(TIM3_IRQn);
  spi_for_flash();

  uint8_t jedec[3], uid[4];
  flash_id(jedec, uid);
  // Manufacturer = 0xef (Winbond)
  // Memory type = 0x40
  // Capacity = 0x16 (2^22 B = 4 MiB = 32 Mib)
  swv_printf("MF = %02x\nID = %02x %02x\nUID = %02x%02x%02x%02x\n",
    jedec[0], jedec[1], jedec[2], uid[0], uid[1], uid[2], uid[3]);

  flash_test_write_breakpoint();
}
#endif

  // Try to connect with the sensors
  struct mpr121_status_t cap_sensors[6];
  cap_sensors[0].channel = 0; cap_sensors[0].addr = 0x5A << 1;
  // cap_sensors[1].channel = 0; cap_sensors[1].addr = 0x5B << 1;
  cap_sensors[1].channel = 0; cap_sensors[1].addr = 0x5D << 1;
  cap_sensors[2].channel = 0; cap_sensors[2].addr = 0x5C << 1;
  cap_sensors[3].channel = 1; cap_sensors[3].addr = 0x5A << 1;
  cap_sensors[4].channel = 1; cap_sensors[4].addr = 0x5C << 1;
  // Infinite loops will be reset by IWDG
  while (1) {
    i2c_err = 0;
    for (int i = 0; i < 5; i++)
      mpr121_reset_status(&cap_sensors[i]);
    HAL_Delay(20);  // Ensure MPR121's have been set up and sampling
    for (int i = 0; i < 5; i++)
      mpr121_read_status(&cap_sensors[i]);
    if (i2c_err != 0) {
      HAL_Delay(300);
      HAL_GPIO_WritePin(LED_PORT, LED_PIN_ACT, GPIO_PIN_RESET);
      HAL_Delay(50);
      HAL_GPIO_WritePin(LED_PORT, LED_PIN_ACT, GPIO_PIN_SET);
    } else {
      break;
    }
  }

  uint32_t last_tick = HAL_GetTick();

/*
  volatile int8_t inspect_index = -1;
  static uint32_t inspect_buffer[200] __attribute__ ((used)) = { 0 };
  uint16_t inspect_buffer_ptr = 0;
*/

  uint32_t last_values[60] = { 0 };
  uint32_t values[60] = { 0 };

  static struct debouncer d[60];
  for (int i = 0; i < 60; i++) d[i].mul = 1000;

  // Strings
  for (int i =  0; i <=  9; i++) d[i].threshold = 80000;
  // Squeaks
  for (int i = 10; i <= 19; i++) d[i].threshold = 700000;
  // Bouncing Bells
  for (int i = 33; i <= 35; i++) d[i].threshold = 1000;
  for (int i = 33; i <= 35; i++) d[i].mul = 10;
  // Picks
  for (int i = 36; i <= 45; i++) d[i].threshold = 500000;
  // Kicks
  for (int i = 46; i <= 52; i++) d[i].threshold = 700000;
  // Bongos
  for (int i = 30; i <= 32; i++) d[i].threshold = 700000;
  for (int i = 53; i <= 58; i++) d[i].threshold = 700000;

  for (int i = 0; i < 60; i++) debouncer_init(&d[i]);

  while (1) {
    HAL_IWDG_Refresh(&iwdg);

    for (int i = 0; i < 5; i++)
      mpr121_read_elas(&cap_sensors[i], values + 12 * i);
    for (int i = 0; i < 60; i++)
      if (values[i] == 0) values[i] = last_values[i];
    memcpy(last_values, values, sizeof values);

    /* bool any_zero = false;
    for (int i = 0; i < 60; i++)
      if (values[i] == 0) { any_zero = true; continue; }
    if (any_zero) continue; */

    for (int i = 0; i < 60; i++)
      // if (!(i >= 33 && i <= 35) && !(i >= 20 && i <= 29))
      //   debouncer_update(&d[i], values[i]);
      if (values[i] != 0)
        debouncer_update(&d[i], (i >= 33 && i <= 35 ? 1000000 - values[i] : values[i]));
    // debouncer_update(&d[33], values[33] + values[34] + values[35]);

    uint32_t fluff_values[10];
    for (int i = 20; i <= 29; i++) fluff_values[i - 20] = values[i];
    /*for (int i = 0; i < 9; i++)
      for (int j = i + 1; j < 10; j++)
        if (fluff_values[i] > fluff_values[j]) {
          uint32_t t = fluff_values[i];
          fluff_values[i] = fluff_values[j];
          fluff_values[j] = t;
        }*/
    uint32_t fluff_sum = 0;
    //for (int i = 3; i <= 7; i++) fluff_sum += fluff_values[i];
    for (int i = 0; i <= 7; i++) if (i != 2 && i != 5) fluff_sum += fluff_values[i];
    debouncer_update(&d[20], fluff_sum);

    for (int i = 0; i <= 9; i++) {
      static int8_t persist_ch[10] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
      static uint8_t persist_timestamp[10];
      if (debouncer_state_switch(&d[i]) && d[i].on) {
        static const uint32_t f[10][2] = {
          {FILE_ADDR___strings1_bin,  FILE_SIZE___strings1_bin},
          {FILE_ADDR___strings2_bin,  FILE_SIZE___strings2_bin},
          {FILE_ADDR___strings3_bin,  FILE_SIZE___strings3_bin},
          {FILE_ADDR___strings4_bin,  FILE_SIZE___strings4_bin},
          {FILE_ADDR___strings5_bin,  FILE_SIZE___strings5_bin},
          {FILE_ADDR___strings6_bin,  FILE_SIZE___strings6_bin},
          {FILE_ADDR___strings7_bin,  FILE_SIZE___strings7_bin},
          {FILE_ADDR___strings8_bin,  FILE_SIZE___strings8_bin},
          {FILE_ADDR___strings9_bin,  FILE_SIZE___strings9_bin},
          {FILE_ADDR___strings10_bin, FILE_SIZE___strings10_bin},
        };
        // swv_printf("On string %d\n", i - 0);
        if (persist_ch[i] != -1 && sampler.channels[persist_ch[i]].enabled == persist_timestamp[i])
          sampler.channels[persist_ch[i]].enabled = 0;
        uint8_t ch = sampler_trigger(&sampler, f[i - 0][0], f[i - 0][0] + f[i - 0][1]);
        sampler.channels[ch].vol = 4096;
        persist_ch[i] = ch;
        persist_timestamp[i] = sampler.channels[ch].enabled;
      }
      if (persist_ch[i] != -1) {
        // XXX: Wraparound?? Is this theoretically possible?
        if (sampler.channels[persist_ch[i]].enabled == persist_timestamp[i]) {
          if (d[i].on) {
            sampler.channels[persist_ch[i]].vol = min(
              4096,
              (int16_t)sampler.channels[persist_ch[i]].vol + 60
            );
          } else {
            sampler.channels[persist_ch[i]].vol = max(
              0,
              (int16_t)sampler.channels[persist_ch[i]].vol - 60
            );
          }
        }
      } else {
        persist_ch[i] = -1;
      }
    }
    for (int i = 10; i <= 19; i++) {
      if (debouncer_state_switch(&d[i]) && d[i].on) {
        static const uint32_t f[10][2] = {
          {FILE_ADDR___squeak1_bin,  FILE_SIZE___squeak1_bin},
          {FILE_ADDR___squeak2_bin,  FILE_SIZE___squeak2_bin},
          {FILE_ADDR___squeak3_bin,  FILE_SIZE___squeak3_bin},
          {FILE_ADDR___squeak4_bin,  FILE_SIZE___squeak4_bin},
          {FILE_ADDR___squeak5_bin,  FILE_SIZE___squeak5_bin},
          {FILE_ADDR___squeak6_bin,  FILE_SIZE___squeak6_bin},
          {FILE_ADDR___squeak7_bin,  FILE_SIZE___squeak7_bin},
          {FILE_ADDR___squeak8_bin,  FILE_SIZE___squeak8_bin},
          {FILE_ADDR___squeak9_bin,  FILE_SIZE___squeak9_bin},
          {FILE_ADDR___squeak10_bin, FILE_SIZE___squeak10_bin},
        };
        // swv_printf("On squeak %d\n", i - 10);
        uint8_t ch = sampler_trigger(&sampler, f[i - 10][0], f[i - 10][0] + f[i - 10][1]);
        sampler.channels[ch].vol = 768;
      }
    }
    /*if (0) for (int i = 33; i <= 35; i++) {
      static const uint32_t f_running[3][2] = {
        {FILE_ADDR___pull1_bin,  FILE_SIZE___pull1_bin},
        {FILE_ADDR___pull2_bin,  FILE_SIZE___pull2_bin},
        {FILE_ADDR___pull3_bin,  FILE_SIZE___pull3_bin},
      };
      static const uint32_t f_finish[2][2] = {
        {FILE_ADDR___bounce1_bin,  FILE_SIZE___bounce1_bin},
        {FILE_ADDR___bounce2_bin,  FILE_SIZE___bounce2_bin},
      };
      if (debouncer_state_switch(&d[i])) {
        if (d[i].on) {
          static int index = 0;
          index = (index + 1) % 3;
          swv_printf("On bell %d\n", index);
          uint8_t ch = sampler_trigger(&sampler,
            f_running[index][0], f_running[index][0] + f_running[index][1]);
          sampler.channels[ch].vol = 256;
        } else {
          static int index = 0;
          index = (index + 1) % 2;
          swv_printf("Off bell %d\n", index);
          uint8_t ch = sampler_trigger(&sampler,
            f_finish[index][0], f_finish[index][0] + f_finish[index][1]);
          sampler.channels[ch].vol = 256;
        }
      }
    }*/
    static const uint32_t f_ber_running[3][2] = {
      {FILE_ADDR___pull1_bin,  FILE_SIZE___pull1_bin/2},
      {FILE_ADDR___pull2_bin,  FILE_SIZE___pull2_bin/2},
      {FILE_ADDR___pull3_bin,  FILE_SIZE___pull3_bin/2},
    };
    static int8_t ber_ch = -1;
    static uint8_t ber_timestamp;
    for (int i = 33; i <= 35; i++) {
      if (debouncer_intensity(&d[i]) >= 1200) {
        if (ber_ch == -1) {
          static int index = 0;
          index = (index + 1) % 3;
          ber_ch = sampler_trigger(&sampler,
            f_ber_running[index][0], f_ber_running[index][0] + f_ber_running[index][1]);
          sampler.channels[ber_ch].vol = 384;
          ber_timestamp = sampler.channels[ber_ch].enabled;
        }
      }
    }
    if (ber_ch != -1 && sampler.channels[ber_ch].enabled != ber_timestamp)
      ber_ch = -1;
    for (int i = 36; i <= 45; i++) {
      if (debouncer_state_switch(&d[i]) && d[i].on) {
        static const uint32_t f[10][2] = {
          {FILE_ADDR___pick1_bin,  FILE_SIZE___pick1_bin},
          {FILE_ADDR___pick2_bin,  FILE_SIZE___pick2_bin},
          {FILE_ADDR___pick3_bin,  FILE_SIZE___pick3_bin},
          {FILE_ADDR___pick4_bin,  FILE_SIZE___pick4_bin},
          {FILE_ADDR___pick5_bin,  FILE_SIZE___pick5_bin},
          {FILE_ADDR___pick6_bin,  FILE_SIZE___pick6_bin},
          {FILE_ADDR___pick7_bin,  FILE_SIZE___pick7_bin},
          {FILE_ADDR___pick8_bin,  FILE_SIZE___pick8_bin},
          {FILE_ADDR___pick9_bin,  FILE_SIZE___pick9_bin},
          {FILE_ADDR___pick10_bin, FILE_SIZE___pick10_bin},
        };
        // swv_printf("On pick %d\n", i - 36);
        uint8_t ch = sampler_trigger(&sampler, f[i - 36][0], f[i - 36][0] + f[i - 36][1]);
        sampler.channels[ch].vol = 8192;
      }
    }
    for (int i = 46; i <= 52; i++) {
      if (debouncer_state_switch(&d[i]) && d[i].on) {
        static const uint32_t f[7][2] = {
          {FILE_ADDR___kick1_bin,  FILE_SIZE___kick1_bin},
          {FILE_ADDR___kick2_bin,  FILE_SIZE___kick2_bin},
          {FILE_ADDR___kick3_bin,  FILE_SIZE___kick3_bin},
          {FILE_ADDR___kick4_bin,  FILE_SIZE___kick4_bin},
          {FILE_ADDR___kick5_bin,  FILE_SIZE___kick5_bin},
          {FILE_ADDR___kick6_bin,  FILE_SIZE___kick6_bin},
          {FILE_ADDR___kick7_bin,  FILE_SIZE___kick7_bin},
        };
        // swv_printf("On kick %d\n", i - 46);
        uint8_t ch = sampler_trigger(&sampler, f[i - 46][0], f[i - 46][0] + f[i - 46][1]);
        sampler.channels[ch].vol = 2048;
      }
    }
    for (int i = 30; i <= 58; i = (i == 32 ? 53 : i + 1)) {
      if (debouncer_state_switch(&d[i]) && d[i].on) {
        static const uint32_t f[9][2] = {
          {FILE_ADDR___Bongo1_bin,  FILE_SIZE___Bongo1_bin},
          {FILE_ADDR___Bongo2_bin,  FILE_SIZE___Bongo2_bin},
          {FILE_ADDR___Bongo3_bin,  FILE_SIZE___Bongo3_bin},
          {FILE_ADDR___Bongo4_bin,  FILE_SIZE___Bongo4_bin},
          {FILE_ADDR___Bongo5_bin,  FILE_SIZE___Bongo5_bin},
          {FILE_ADDR___Bongo6_bin,  FILE_SIZE___Bongo6_bin},
          {FILE_ADDR___Bongo7_bin,  FILE_SIZE___Bongo7_bin},
          {FILE_ADDR___Bongo8_bin,  FILE_SIZE___Bongo8_bin},
          {FILE_ADDR___Bongo1_bin,  FILE_SIZE___Bongo1_bin},
        };
        int index = (i <= 32 ? i - 30 : i - 53 + 3);
        // swv_printf("On bongo %d\n", index);
        uint8_t ch = sampler_trigger(&sampler, f[index][0], f[index][0] + f[index][1]);
        sampler.channels[ch].vol = 2048;
      }
    }

    /* static int T = 0;
    if (++T == 10) {
      T = 0;
      static bool borders[60] = { false };
      borders[ 0] = borders[10] = borders[20] = borders[30] =
      borders[33] = borders[36] = borders[46] = borders[53] = borders[56] = true;
      for (int i = 33; i <= 35; i++)
        swv_printf("%s%7u", borders[i] ? " | " : " ", values[i]);
      for (int i = 33; i <= 35; i++)
        swv_printf("%s%7d", borders[i] ? " | " : " ", 1000000 - d[i].highhigh);
      for (int i = 33; i <= 35; i++)
        swv_printf("%s%7d", borders[i] ? " | " : " ", debouncer_intensity(&d[i]));
      //swv_printf("%7u %7u %7u | %7u", values[33] + values[34] + values[35],
      //  d[33].high, d[33].highhigh, fluff_sum);
      swv_printf("\n");
    }

    // Workaround when there's no SWO and no semihosting
    if (inspect_index != -1) {
      inspect_buffer[inspect_buffer_ptr++] = values[inspect_index];
    }
    if (inspect_index == -1 || inspect_buffer_ptr == (sizeof inspect_buffer / sizeof inspect_buffer[0])) {
      inspect_index = inspect_index; // Print `inspect_buffer`, update `inspect_index` and continue
      inspect_buffer_ptr = 0;
    } */

    // Delay 10 ms
    uint32_t cur_tick;
    // uint32_t diff = HAL_GetTick() - last_tick;
    // swv_printf("diff = %u\n", diff);
    do cur_tick = HAL_GetTick(); while (cur_tick < last_tick + 10);
    last_tick = cur_tick;

    static int total = 0;
    if (++total == 100) {
      swv_printf("SysTick = %u, CYCCNT = %u\n", HAL_GetTick(), DWT->CYCCNT);
      HAL_GPIO_WritePin(LED_PORT, LED_PIN_ACT, !HAL_GPIO_ReadPin(LED_PORT, LED_PIN_ACT));
      total = 0;
    }
  }
}

void SysTick_Handler()
{
  HAL_IncTick();
  HAL_SYSTICK_IRQHandler();
}

void TIM2_IRQHandler()
{
  HAL_TIM_IRQHandler(&tim2);
}
void TIM3_IRQHandler()
{
  HAL_TIM_IRQHandler(&tim3);
}
uint32_t total_sample_count = 0;
static inline int16_t clamp_s16(int32_t x)
{
  if (x >  0x7fff) return  0x7fff;
  if (x < -0x8000) return -0x8000;
  return x;
}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *tim)
{
#ifdef INSPECT_SAMPLES
  static int16_t samples_buffer[INSPECT_SAMPLES] __attribute__ ((used));
  static uint32_t samples_buffer_ptr = 0;
#endif
  if (tim == &tim2) {
    // Latch sample output
    spi_for_dac();
    dac_write(sample_output);
    // Calculate the next sample
    int32_t sample_new = sampler_next(&sampler);
    sample_output = clamp_s16(sample_new);
    total_sample_count++;
#ifdef INSPECT_SAMPLES
    if (samples_buffer_ptr < (sizeof samples_buffer) / (sizeof samples_buffer[0])) {
      samples_buffer[samples_buffer_ptr++] = (int16_t)sample_output;
    } else {
      // swv_printf("full!\n");
      samples_buffer_ptr = 0;
    }
#endif
  } else {
    // Finish undecoded samples
    sampler_finish_decode(&sampler);
  }
}

void SPI1_IRQHandler()
{
  HAL_SPI_IRQHandler(&spi1);
}

void DMA1_Channel2_IRQHandler()
{
  HAL_DMA_IRQHandler(spi1.hdmarx);
}

void DMA1_Channel3_IRQHandler()
{
  HAL_DMA_IRQHandler(spi1.hdmatx);
}
