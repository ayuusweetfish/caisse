#include <assert.h>

#define uQOA_IMPL
#include "uqoa.h"

// ======== Debug ========

static uint8_t swv_buf[256];
static size_t swv_buf_ptr = 0;
__attribute__ ((noinline))
void swv_trap_line()
{
  ITM_SendChar(swv_buf[0]);
}

static inline void swv_putchar(uint8_t c)
{
  // ITM_SendChar(c);
  if (c == '\n') {
    swv_buf[swv_buf_ptr >= sizeof swv_buf ?
      (sizeof swv_buf - 1) : swv_buf_ptr] = '\0';
    swv_trap_line();
    swv_buf_ptr = 0;
  } else if (++swv_buf_ptr <= sizeof swv_buf) {
    swv_buf[swv_buf_ptr - 1] = c;
  }
}

static void swv_printf(const char *restrict fmt, ...)
{
  char s[256];
  va_list args;
  va_start(args, fmt);
  int r = vsnprintf(s, sizeof s, fmt, args);
  for (int i = 0; i < r && i < sizeof s - 1; i++) swv_putchar(s[i]);
  if (r >= sizeof s) {
    for (int i = 0; i < 3; i++) swv_putchar('.');
    swv_putchar('\n');
  }
}

static inline void dwt_delay(uint32_t cycles)
{
  uint32_t start = DWT->CYCCNT;
  while (DWT->CYCCNT - start < cycles) { }
}

// ======== I2C and devices ========

// 2.5 us = 400 kHz
#define I2Cx_DELAY      (1.25 * CYC_MICROSECOND)
#define I2Cx_delay()    dwt_delay(I2Cx_DELAY)
#define I2Cx_PORT       GPIOB
#define I2Cx_PIN_SCL    GPIO_PIN_5
#define I2Cx_PIN_SDA_0  GPIO_PIN_6
#define I2Cx_PIN_SDA_1  GPIO_PIN_7
static uint8_t i2c_channel = 0;
#define I2Cx_PIN_SDA_C  (i2c_channel == 0 ? I2Cx_PIN_SDA_0 : I2Cx_PIN_SDA_1)
static inline bool read_SCL() { return I2Cx_PORT->IDR & I2Cx_PIN_SCL; }
static inline bool read_SDA() { return I2Cx_PORT->IDR & I2Cx_PIN_SDA_C; }
static inline void set_SCL() { I2Cx_PORT->BSRR = I2Cx_PIN_SCL; }
static inline void clear_SCL() { I2Cx_PORT->BSRR = (uint32_t)I2Cx_PIN_SCL << 16; }
static inline void set_SDA() { I2Cx_PORT->BSRR = I2Cx_PIN_SDA_C; }
static inline void clear_SDA() { I2Cx_PORT->BSRR = (uint32_t)I2Cx_PIN_SDA_C << 16; }

// 0 - no error
// 1 - no acknowledgement
// 2 - timeout
// 4 - bus error, arbitration lost
static int i2c_err = 0;
static int i2c_first_err_line = -1;

__attribute__ ((noinline))
static void i2c_mark_err(int line, int flag)
{
  if (i2c_err == 0) i2c_first_err_line = line;
  i2c_err |= flag;
}

static void wait_SCL_rise(int line)
{
  uint32_t start = DWT->CYCCNT;
  do {
    if (read_SCL()) return;
  } while (DWT->CYCCNT - start < I2Cx_DELAY * 128);
  i2c_mark_err(line, 2);
}

static bool started = false;

static inline void i2c_init()
{
  clear_SCL();
  clear_SDA();
}

#pragma GCC optimize("O3")
static inline void i2c_start_cond(void)
{
  if (true || started) {  // XXX: ?
    set_SDA(); I2Cx_delay();
    set_SCL(); wait_SCL_rise(__LINE__); I2Cx_delay();
  }

  if (read_SDA() == 0) {
    i2c_mark_err(__LINE__, 4);
    return;
  }

  clear_SDA(); I2Cx_delay();
  clear_SCL();
  started = true;
}

#pragma GCC optimize("O3")
static inline void i2c_stop_cond(void)
{
  clear_SDA(); I2Cx_delay();
  set_SCL(); wait_SCL_rise(__LINE__); I2Cx_delay();
  set_SDA(); I2Cx_delay();

  if (read_SDA() == 0) {
    i2c_mark_err(__LINE__, 4);
    return;
  }

  started = false;
}

#pragma GCC optimize("O3")
// Write a bit to I2C bus
static inline void i2c_write_bit(bool bit)
{
  if (bit) { set_SDA(); } else { clear_SDA(); } I2Cx_delay();
  set_SCL(); wait_SCL_rise(__LINE__); I2Cx_delay();

  if (bit && (read_SDA() == 0)) {
    i2c_mark_err(__LINE__, 4);
    return;
  }

  clear_SCL();
}

#pragma GCC optimize("O3")
// Read a bit from I2C bus
static inline bool i2c_read_bit(void)
{
  bool bit;
  set_SDA(); I2Cx_delay();
  set_SCL(); wait_SCL_rise(__LINE__); I2Cx_delay();

  bit = read_SDA();
  clear_SCL();

  return bit;
}

#pragma GCC optimize("O3")
// Write a byte to I2C bus. Return 0 if ack by the target.
static inline bool i2c_write_byte(uint8_t byte)
{
  unsigned bit;
  bool     nack;

  for (bit = 0; bit < 8; ++bit) {
    i2c_write_bit((byte & 0x80) != 0);
    byte <<= 1;
  }

  nack = i2c_read_bit();

  if (nack) i2c_mark_err(__LINE__, 1);
  return nack;
}

#pragma GCC optimize("O3")
// Read a byte from I2C bus
static inline uint8_t i2c_read_byte(bool send_stop)
{
  uint8_t byte = 0;
  uint8_t bit;

  for (bit = 0; bit < 8; ++bit) {
    byte = (byte << 1) | i2c_read_bit();
  }

  i2c_write_bit(send_stop);

  if (send_stop) {
    i2c_stop_cond();
  }

  return byte;
}

#pragma GCC optimize("O3")
static inline void i2c_write(uint8_t addr, const uint8_t *data, size_t size)
{
  i2c_start_cond();
  i2c_write_byte(addr);
  for (size_t i = 0; i < size; i++)
    i2c_write_byte(data[i]);
  i2c_stop_cond();
}

#pragma GCC optimize("O3")
static inline void i2c_read(uint8_t addr, uint8_t *buf, size_t size)
{
  i2c_start_cond();
  for (size_t i = 0; i < size; i++)
    buf[i] = i2c_read_byte(i == size - 1);
}

#pragma GCC optimize("O3")
static inline void i2c_write_reg_byte(uint8_t addr, uint8_t reg, uint8_t data)
{
  i2c_start_cond();
  i2c_write_byte(addr);
  i2c_write_byte(reg);
  i2c_write_byte(data);
  i2c_stop_cond();
}

#pragma GCC optimize("O3")
static inline void i2c_read_reg(uint8_t addr, uint8_t reg, size_t size, uint8_t *buf)
{
  i2c_start_cond();
  i2c_write_byte(addr);
  i2c_write_byte(reg);
  i2c_start_cond();
  i2c_write_byte(addr | 1);
  for (size_t i = 0; i < size; i++)
    buf[i] = i2c_read_byte(i == size - 1);
}
// End of I2C

static inline void mpr121_reset(uint8_t channel, uint8_t addr, uint8_t n_electrodes)
{
  i2c_channel = channel;
  // Soft Reset
  i2c_write_reg_byte(addr, 0x80, 0x63);
  // Up-Side Limit / Low-Side Limit / Target Level Register
  // USL = 2.6/3.3 * 256
  //  TL = USL * 0.9
  // LSL = USL * 0.5
  i2c_write_reg_byte(addr, 0x7D, 202);
  i2c_write_reg_byte(addr, 0x7F, 182);
  i2c_write_reg_byte(addr, 0x7E, 101);
  // Filter/Global CDT Configuration Register (0x5D)
  // CDT = 000, SFI = 00, ESI = 010
  i2c_write_reg_byte(addr, 0x5D, 0x02);
  // Auto-Configure Control Register 0
  // FFI = 00, RETRY = 00, BVA = 10, ARE = 0, ACE = 1
  i2c_write_reg_byte(addr, 0x7B, 0x09);
/*
  // Manual configuration
  for (int i = 0; i < n_electrodes; i++) {
    // ELEx Electrode Current
    i2c_write_reg_byte(addr, 0x5F + i, 0x25);
    if (i % 2 == 0) {
      // ELEx Charge Time
      i2c_write_reg_byte(addr, 0x6C + (i / 2), i + 1 >= n_electrodes ? 0x01 : 0x11);
    }
  }
*/
  // Electrode Configuration Register (ECR)
  i2c_write_reg_byte(addr, 0x5E, 0x40 + n_electrodes);
}

static inline void mpr121_readout(uint8_t channel, uint8_t addr, uint8_t n_electrodes, uint16_t values[])
{
  i2c_channel = channel;
  uint8_t attempts = 0;
  // May be optimised on architectures known to be little endian, but for portability
  uint8_t buf[24];
start:
  i2c_err = 0;
  i2c_read_reg(addr, 0x04, n_electrodes * 2, buf);
  if (i2c_err != 0) {
    for (int i = 0; i < n_electrodes; i++) values[i] = 2048;
  } else {
    for (int i = 0; i < n_electrodes; i++)
      values[i] = ((uint16_t)buf[i * 2 + 1] << 8) | buf[i * 2 + 0];
  }
/*
  if (values[0] == 0) {
    // The chip might not be ready. Wait and retry.
    if (++attempts == 3) return;
    HAL_Delay(10);
    goto start;
  }
*/
}

static inline void mpr121_calibrate(uint8_t channel, uint8_t addr, uint8_t n_electrodes)
{
  i2c_write_reg_byte(addr, 0x5E, 0x40);
  i2c_write_reg_byte(addr, 0x5E, 0x40 + n_electrodes);
}

struct mpr121_status_t {
  uint8_t channel, addr;
  bool recalibrate;
  // CDC encoding: 1~63 corresponds to 1~63 µA
  uint8_t charge_current[12];
  // CDT encoding: 1~7 corresponds to 0.5~32 µs
  uint8_t charge_time[12];
};

static inline void mpr121_read_status(struct mpr121_status_t *st)
{
  i2c_channel = st->channel;
  uint8_t buf[0x71 - 0x5F + 1];
  // Inspect OVF?
  // i2c_read_reg(st->addr, 0x0, 2, buf);
  // swv_printf("%u %u\n", buf[0], buf[1]);
  i2c_read_reg(st->addr, 0x5F, 0x71 - 0x5F + 1, buf);
  for (int i = 0; i < 12; i++) {
    st->charge_current[i] = buf[i];
    st->charge_time[i] =
      (buf[(0x6C - 0x5F) + (i / 2)] >> ((i % 2) * 4)) & 0x7;
  }
}

static inline void mpr121_reset_status(struct mpr121_status_t *st)
{
  mpr121_reset(st->channel, st->addr, 12);
  // mpr121_read_status(st);
}

// #pragma GCC optimize("O0")
// 1e8/elas is the capacitance in picofarads
static inline void mpr121_read_elas(struct mpr121_status_t *st, uint32_t elas[12])
{
  if (st->recalibrate) {
    st->recalibrate = false;
    mpr121_read_status(st);
  }

  // C = I * T / V = CDC * CDT / (ADC * VDD / 1024)
  // Elastance = ADC * VDD / 1024 / (CDC * CDT)
  uint16_t values[12];
  mpr121_readout(st->channel, st->addr, 12, values);

  bool recalibrate = false;
  for (int i = 0; i < 12; i++) {
    if (st->charge_current[i] != 0 && st->charge_time[i] != 0) {
      // 2000000 * 3.3 / 1024 = 6445.3125
      // elas[i] = (uint32_t)values[i]
      //   * 644531 / st->charge_current[i] / (1 << (st->charge_time[i] - 1));
      // list(int(round(6445.3125 * 100 / x)) for x in range(1, 64))
      static const uint32_t div_table[64] = {
        0, 644531, 322266, 214844, 161133, 128906, 107422, 92076, 80566, 71615, 64453, 58594, 53711, 49579, 46038, 42969, 40283, 37914, 35807, 33923, 32227, 30692, 29297, 28023, 26855, 25781, 24790, 23872, 23019, 22225, 21484, 20791, 20142, 19531, 18957, 18415, 17904, 17420, 16961, 16526, 16113, 15720, 15346, 14989, 14648, 14323, 14012, 13713, 13428, 13154, 12891, 12638, 12395, 12161, 11936, 11719, 11509, 11308, 11113, 10924, 10742, 10566, 10396, 10231
      };
      elas[i] = ((uint32_t)values[i] * div_table[st->charge_current[i]])
        >> (st->charge_time[i] - 1);
    } else {
      elas[i] = 0;
    }
    if (values[i] != 0 &&
        (values[i] < 400 || values[i] >= 800))
      recalibrate = true;
  }

  if (recalibrate) {
    mpr121_calibrate(st->channel, st->addr, 12);
    st->recalibrate = true;
  }
}

// ======== SPI and devices ========

#pragma GCC optimize("O3")
// __attribute__ ((noinline))
static inline void spi_transmit(uint8_t *data, size_t size)
{
  // HAL_SPI_Transmit(&spi1, data, size, 1000); return;
  for (int i = 0; i < size; i++) {
    while (!(SPI1->SR & SPI_SR_TXE)) { }
    SPI1->DR = data[i];
  }
  while (!(SPI1->SR & SPI_SR_TXE)) { }
  while ((SPI1->SR & SPI_SR_BSY)) { }
  // Clear OVR flag
  (void)SPI1->DR;
  (void)SPI1->SR;
}

#pragma GCC optimize("O3")
// __attribute__ ((noinline))
static inline void spi_receive(uint8_t *data, size_t size)
{
  // HAL_SPI_Receive(&spi1, data, size, 1000); return;
  for (int i = 0; i < size; i++) {
    while (!(SPI1->SR & SPI_SR_TXE)) { }
    SPI1->DR = 0;
    while (!(SPI1->SR & SPI_SR_RXNE)) { }
    data[i] = (uint8_t)SPI1->DR;
  }
  while (!(SPI1->SR & SPI_SR_TXE)) { }
  while ((SPI1->SR & SPI_SR_BSY)) { }
}

static inline void spi_for_flash()
{
  // Set clock rate to f_PCLK / 2 = 18 MHz - max. 50 MHz
  // Corresponds to SPI_InitTypeDef.BaudRatePrescaler, but no need to let HAL know
  SPI1->CR1 = (SPI1->CR1 & ~SPI_CR1_BR_Msk) | 0;
  // Set data size to 8 bits
  SPI1->CR1 = (SPI1->CR1 & ~SPI_CR1_DFF) | 0;
  // spi1.Init.DataSize = SPI_DATASIZE_8BIT;
}

static inline void spi_for_dac()
{
  // Set clock rate to f_PCLK / 2 = 18 MHz - max. 20 MHz
  SPI1->CR1 = (SPI1->CR1 & ~SPI_CR1_BR_Msk) | SPI_CR1_BR_0;
  // Set data size to 16 bits
  SPI1->CR1 = (SPI1->CR1 & ~SPI_CR1_DFF) | SPI_CR1_DFF;
  // spi1.Init.DataSize = SPI_DATASIZE_16BIT;
}

#pragma GCC optimize("O3")
// __attribute__ ((noinline))
static inline void spi_flash_tx_rx(
  GPIO_TypeDef *cs_port, uint32_t cs_pin,
  uint8_t *txbuf, size_t txsize,
  uint8_t *rxbuf, size_t rxsize
) {
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 16;
  spi_transmit(txbuf, txsize);
  if (rxsize != 0) {
    while (SPI1->SR & SPI_SR_BSY) { }
    spi_receive(rxbuf, rxsize);
  }
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 0;
}

#pragma GCC optimize("O3")
static inline void dac_write(int16_t sample)
{
  DAC_CS_PORT->BSRR = (uint32_t)DAC_CS_PIN << 16;
  uint16_t out_data = (0b0111UL << 12) | ((uint16_t)(sample + 32768) >> 4);
  SPI1->DR = out_data;
  while (!(SPI1->SR & SPI_SR_TXE)) { }
  while (SPI1->SR & SPI_SR_BSY) { }
  DAC_CS_PORT->BSRR = (uint32_t)DAC_CS_PIN << 0;
}

#define flash_cmd(_cmd) \
  spi_flash_tx_rx(FLASH_CS_PORT, FLASH_CS_PIN, (_cmd), sizeof (_cmd), NULL, 0)
#define flash_cmd_sized(_cmd, _cmdlen) \
  spi_flash_tx_rx(FLASH_CS_PORT, FLASH_CS_PIN, (_cmd), (_cmdlen), NULL, 0)
#define flash_cmd_bi(_cmd, _rxbuf) \
  spi_flash_tx_rx(FLASH_CS_PORT, FLASH_CS_PIN, (_cmd), sizeof (_cmd), (_rxbuf), sizeof (_rxbuf))
#define flash_cmd_bi_sized(_cmd, _cmdlen, _rxbuf, _rxlen) \
  spi_flash_tx_rx(FLASH_CS_PORT, FLASH_CS_PIN, (_cmd), (_cmdlen), (_rxbuf), (_rxlen))

uint8_t flash_status0()
{
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 16;
  uint8_t op_read_status[] = {0x05};
  spi_transmit(op_read_status, sizeof op_read_status);
  uint8_t status0;
  spi_receive(&status0, 1);
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 0;
  return status0;
}

__attribute__ ((noinline))
uint32_t flash_status_all()
{
  uint8_t op_read_status;
  uint8_t status[3];
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 16;
  op_read_status = 0x05; spi_transmit(&op_read_status, 1); spi_receive(&status[0], 1);
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 0;
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 16;
  op_read_status = 0x35; spi_transmit(&op_read_status, 1); spi_receive(&status[1], 1);
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 0;
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 16;
  op_read_status = 0x15; spi_transmit(&op_read_status, 1); spi_receive(&status[2], 1);
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 0;
  return ((uint32_t)status[2] << 16) | ((uint32_t)status[1] << 8) | status[0];
}

void flash_wait_poll(uint32_t interval_us)
{
  uint8_t status0;
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 16;
  uint8_t op_read_status[] = {0x05};
  spi_transmit(op_read_status, sizeof op_read_status);
  do {
    dwt_delay(interval_us * CYC_MICROSECOND);
    spi_receive(&status0, 1);
    // swv_printf("BUSY = %u, SysTick = %lu\n", status0 & 1, HAL_GetTick());
  } while (status0 & 1);
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 0;
}

void flash_id(uint8_t jedec[3], uint8_t uid[4])
{
  uint8_t op_read_jedec[] = {0x9F};
  flash_cmd_bi_sized(op_read_jedec, sizeof op_read_jedec, jedec, 3);
  uint8_t op_read_uid[] = {0x4B, 0x00, 0x00, 0x00, 0x00};
  flash_cmd_bi_sized(op_read_uid, sizeof op_read_uid, uid, 4);
}

#pragma GCC optimize("O0")
void flash_erase_4k(uint32_t addr)
{
  addr &= ~0xFFF;
  uint8_t op_write_enable[] = {0x06};
  flash_cmd(op_write_enable);
  uint8_t status = flash_status0();
  swv_printf("%d\n", status);
  uint8_t op_sector_erase[] = {
    0x20, // Sector Erase
    (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, (addr >> 0) & 0xFF,
  };
  flash_cmd(op_sector_erase);
  // Wait for completion (t_SE max. = 400 ms, typ. = 40 ms)
  flash_wait_poll(1000);
}

void flash_erase_64k(uint32_t addr)
{
  addr &= ~0xFFFF;
  uint8_t op_write_enable[] = {0x06};
  flash_cmd(op_write_enable);
  uint8_t op_sector_erase[] = {
    0xD8, // 64KB Block Erase
    (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, (addr >> 0) & 0xFF,
  };
  flash_cmd(op_sector_erase);
  // Wait for completion (t_BE2 max. = 2000 ms, typ. = 150 ms)
  flash_wait_poll(1000);
}

void flash_erase_chip()
{
  uint8_t op_write_enable[] = {0xC7};
  flash_cmd(op_write_enable);
  uint8_t op_chip_erase[] = {
    0x20, // Chip Erase
  };
  flash_cmd(op_chip_erase);
  // Wait for completion (t_CE max. = 25000 ms, typ. = 5000 ms)
  flash_wait_poll(10000);
}

void flash_write_page(uint32_t addr, uint8_t *data, size_t size)
{
  assert(size > 0 && size <= 256);
  uint8_t op_write_enable[] = {0x06};
  flash_cmd(op_write_enable);
  uint8_t op_page_program[260] = {
    0x02, // Page Program
    (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, (addr >> 0) & 0xFF,
  };
  for (size_t i = 0; i < size; i++)
    op_page_program[4 + i] = data[i];
  flash_cmd_sized(op_page_program, 4 + size);
  // Wait for completion (t_PP max. = 3 ms, typ. = 0.4 ms)
  flash_wait_poll(100);
}

// __attribute__ ((noinline))
void flash_read(uint32_t addr, uint8_t *data, size_t size)
{
  uint8_t op_read_data[] = {
    0x03, // Read Data
    (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, (addr >> 0) & 0xFF,
  };
  flash_cmd_bi_sized(op_read_data, sizeof op_read_data, data, size);
}

HAL_StatusTypeDef HAL_SPI_TransmitReceive_DMA_1(SPI_HandleTypeDef *hspi, uint8_t *pTxData, uint8_t *pRxData,
                                              uint16_t Size)
{
/*
  HAL_DMA_Start_IT(hspi->hdmarx, (uint32_t)&hspi->Instance->DR, (uint32_t)pRxData, Size);
  SPI1->CR2 |= SPI_CR2_RXDMAEN;
  HAL_DMA_Start_IT(hspi->hdmatx, (uint32_t)pTxData, (uint32_t)&hspi->Instance->DR, Size);
  SPI1->CR2 |= SPI_CR2_TXDMAEN;
*/
  uint32_t             tmp_mode;
  HAL_SPI_StateTypeDef tmp_state;
  HAL_StatusTypeDef errorcode = HAL_OK;

  /* Process locked */
  __HAL_LOCK(hspi);

  /* Init temporary variables */
  tmp_state           = hspi->State;
  tmp_mode            = hspi->Init.Mode;

  if (!((tmp_state == HAL_SPI_STATE_READY) ||
        ((tmp_mode == SPI_MODE_MASTER) && (hspi->Init.Direction == SPI_DIRECTION_2LINES) && (tmp_state == HAL_SPI_STATE_BUSY_RX))))
  {
    errorcode = HAL_BUSY;
    goto error;
  }

  /* Don't overwrite in case of HAL_SPI_STATE_BUSY_RX */
  if (hspi->State != HAL_SPI_STATE_BUSY_RX)
  {
    hspi->State = HAL_SPI_STATE_BUSY_TX_RX;
  }

  /* Enable the Rx DMA Stream/Channel  */
  HAL_DMA_Start_IT(hspi->hdmarx, (uint32_t)&hspi->Instance->DR, (uint32_t)pRxData, Size);
  SET_BIT(hspi->Instance->CR2, SPI_CR2_RXDMAEN);

  /* Enable the Tx DMA Stream/Channel  */
  HAL_DMA_Start_IT(hspi->hdmatx, (uint32_t)pTxData, (uint32_t)&hspi->Instance->DR, Size);
  SET_BIT(hspi->Instance->CR2, SPI_CR2_TXDMAEN);

error :
  /* Process Unlocked */
  __HAL_UNLOCK(hspi);
  return errorcode;
}
void flash_read_dma(uint32_t addr, uint8_t *data, size_t size)
{
  uint8_t op_read_data[] = {
    0x03, // Read Data
    (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, (addr >> 0) & 0xFF,
  };
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 16;
  spi_transmit(op_read_data, sizeof op_read_data);
  HAL_SPI_TransmitReceive_DMA(&spi1, data, data, size);
  while (spi1.Instance->SR & SPI_SR_BSY) { }
  FLASH_CS_PORT->BSRR = (uint32_t)FLASH_CS_PIN << 0;
}

#define FILE_ADDR___Bongo1_bin     0
#define FILE_SIZE___Bongo1_bin     6296
#define FILE_ADDR___Bongo2_bin     6296
#define FILE_SIZE___Bongo2_bin     11616
#define FILE_ADDR___Bongo3_bin     17912
#define FILE_SIZE___Bongo3_bin     11632
#define FILE_ADDR___Bongo4_bin     29544
#define FILE_SIZE___Bongo4_bin     7568
#define FILE_ADDR___Bongo5_bin     37112
#define FILE_SIZE___Bongo5_bin     8832
#define FILE_ADDR___Bongo6_bin     45944
#define FILE_SIZE___Bongo6_bin     4392
#define FILE_ADDR___Bongo7_bin     50336
#define FILE_SIZE___Bongo7_bin     8720
#define FILE_ADDR___Bongo8_bin     59056
#define FILE_SIZE___Bongo8_bin     9712
#define FILE_ADDR___bounce1_bin    68768
#define FILE_SIZE___bounce1_bin    38704
#define FILE_ADDR___bounce2_bin    107472
#define FILE_SIZE___bounce2_bin    19456
#define FILE_ADDR___pull1_bin      126928
#define FILE_SIZE___pull1_bin      38704
#define FILE_ADDR___pull2_bin      165632
#define FILE_SIZE___pull2_bin      38704
#define FILE_ADDR___pull3_bin      204336
#define FILE_SIZE___pull3_bin      38704
#define FILE_ADDR___fluff_bin      243040
#define FILE_SIZE___fluff_bin      353408
#define FILE_ADDR___kick1_bin      596448
#define FILE_SIZE___kick1_bin      15552
#define FILE_ADDR___kick2_bin      612000
#define FILE_SIZE___kick2_bin      4064
#define FILE_ADDR___kick3_bin      616064
#define FILE_SIZE___kick3_bin      3040
#define FILE_ADDR___kick4_bin      619104
#define FILE_SIZE___kick4_bin      8856
#define FILE_ADDR___kick5_bin      627960
#define FILE_SIZE___kick5_bin      19768
#define FILE_ADDR___kick6_bin      647728
#define FILE_SIZE___kick6_bin      7776
#define FILE_ADDR___kick7_bin      655504
#define FILE_SIZE___kick7_bin      1864
#define FILE_ADDR___pick1_bin      657368
#define FILE_SIZE___pick1_bin      43936
#define FILE_ADDR___pick10_bin     701304
#define FILE_SIZE___pick10_bin     22008
#define FILE_ADDR___pick2_bin      723312
#define FILE_SIZE___pick2_bin      16448
#define FILE_ADDR___pick3_bin      739760
#define FILE_SIZE___pick3_bin      20400
#define FILE_ADDR___pick4_bin      760160
#define FILE_SIZE___pick4_bin      39880
#define FILE_ADDR___pick5_bin      800040
#define FILE_SIZE___pick5_bin      41544
#define FILE_ADDR___pick6_bin      841584
#define FILE_SIZE___pick6_bin      40392
#define FILE_ADDR___pick7_bin      881976
#define FILE_SIZE___pick7_bin      25824
#define FILE_ADDR___pick8_bin      907800
#define FILE_SIZE___pick8_bin      19976
#define FILE_ADDR___pick9_bin      927776
#define FILE_SIZE___pick9_bin      13848
#define FILE_ADDR___squeak1_bin    941624
#define FILE_SIZE___squeak1_bin    25624
#define FILE_ADDR___squeak10_bin   967248
#define FILE_SIZE___squeak10_bin   5960
#define FILE_ADDR___squeak2_bin    973208
#define FILE_SIZE___squeak2_bin    16960
#define FILE_ADDR___squeak3_bin    990168
#define FILE_SIZE___squeak3_bin    23488
#define FILE_ADDR___squeak4_bin    1013656
#define FILE_SIZE___squeak4_bin    18664
#define FILE_ADDR___squeak5_bin    1032320
#define FILE_SIZE___squeak5_bin    7160
#define FILE_ADDR___squeak6_bin    1039480
#define FILE_SIZE___squeak6_bin    31160
#define FILE_ADDR___squeak7_bin    1070640
#define FILE_SIZE___squeak7_bin    30392
#define FILE_ADDR___squeak8_bin    1101032
#define FILE_SIZE___squeak8_bin    13752
#define FILE_ADDR___squeak9_bin    1114784
#define FILE_SIZE___squeak9_bin    8360
#define FILE_ADDR___strings1_bin   1123144
#define FILE_SIZE___strings1_bin   52560
#define FILE_ADDR___strings10_bin  1175704
#define FILE_SIZE___strings10_bin  54216
#define FILE_ADDR___strings2_bin   1229920
#define FILE_SIZE___strings2_bin   48352
#define FILE_ADDR___strings3_bin   1278272
#define FILE_SIZE___strings3_bin   58480
#define FILE_ADDR___strings4_bin   1336752
#define FILE_SIZE___strings4_bin   56112
#define FILE_ADDR___strings5_bin   1392864
#define FILE_SIZE___strings5_bin   62408
#define FILE_ADDR___strings6_bin   1455272
#define FILE_SIZE___strings6_bin   69168
#define FILE_ADDR___strings7_bin   1524440
#define FILE_SIZE___strings7_bin   64624
#define FILE_ADDR___strings8_bin   1589064
#define FILE_SIZE___strings8_bin   64856
#define FILE_ADDR___strings9_bin   1653920
#define FILE_SIZE___strings9_bin   61664

uint8_t flash_test_write_buf[256 * 8];

// __attribute__ ((used)) // not working, maybe stripped?
__attribute__ ((noinline))
void flash_test_write(uint32_t addr, size_t size)
{
  for (uint32_t block_start = 0; block_start < size; block_start += 256) {
    uint32_t block_size = 256;
    if (block_start + block_size >= size)
      block_size = size - block_start;
    flash_write_page(
      addr + block_start,
      flash_test_write_buf + block_start,
      block_size
    );
  }
}

void flash_test_write_breakpoint()
{
  swv_printf("%d\n", flash_status_all());
  if (*(volatile uint32_t *)flash_test_write_buf == 0x11223344) {
    uint8_t data[4] = {1, 2, 3, 4};
    flash_read(0, data, sizeof data);
    for (int i = 0; i < 4; i++) swv_printf("%d\n", data[i]);
    flash_erase_4k(0);
    flash_erase_64k(0);
    flash_erase_chip();
    flash_test_write(0, 1);
  }
  while (1) { }
}

// ======== Sampler ========

#define SAMPLER_POLYPHONY 4
#define SAMPLER_SLICE_BATCH 8
struct sampler_t {
  struct sampler_channel_t {
    uint8_t enabled;  // Timestamp
    uint16_t vol;
    int16_t samples[20 * SAMPLER_SLICE_BATCH];
    uint8_t sample_ptr;
    // Backbuffer
    bool back_state_read, back_state_decoded;
    int16_t samples_back[20 * SAMPLER_SLICE_BATCH];
    uint64_t slices[SAMPLER_SLICE_BATCH];
    uint8_t slices_ctr;
    uint32_t addr_ptr, addr_end;
    qoa_lms lms;
  } channels[SAMPLER_POLYPHONY];
};

#pragma GCC optimize("O3")
static inline void sampler_channel_read(struct sampler_channel_t *ch)
{
  // Read the next batch of slices
  uint32_t addr = ch->addr_ptr;
  uint32_t addr_end = ch->addr_end;
  // First, stop if going past the end of the sample
  if (addr >= addr_end) {
    ch->enabled = 0;
    return;
  }

  spi_for_flash();

  uint8_t buf[16 + 8 * SAMPLER_SLICE_BATCH];
  bool state_dump = (ch->slices_ctr == 0);
  uint32_t addr_max = addr + (state_dump ? 16 : 0) + sizeof ch->slices;
  if (addr_max >= addr_end) addr_max = addr_end;
  // uint32_t cyc0 = DWT->CYCCNT;
  // flash_read(addr, buf, addr_max - addr);
  flash_read_dma(addr, buf, addr_max - addr);
  // uint32_t cyc1 = DWT->CYCCNT;
  // swv_printf("read size = %d, cycles = %u\n", (int)(addr_max - addr), (unsigned)(cyc1 - cyc0));
  ch->addr_ptr = addr_max;

  // XXX: Use little-endian at encode time
  // An LMS state dump?
  if (state_dump) {
    for (int i = 0; i < 4; i++)
      ch->lms.history[i] = ((int16_t)(buf[i * 2 + 0]) << 8) | buf[i * 2 + 1];
    for (int i = 0; i < 4; i++)
      ch->lms.weights[i] = ((int16_t)(buf[i * 2 + 8]) << 8) | buf[i * 2 + 9];
  }
  // Builtin bug?
  // uint64_t *slices = (uint64_t *)(buf + (state_dump ? 16 : 0));
  // for (int i = 0; i < 8; i++)
  //   ch->slices[i] = __builtin_bswap64(slices[i]);
  uint8_t *slices_start = buf + (state_dump ? 16 : 0);
  for (int i = 0; i < SAMPLER_SLICE_BATCH; i++) {
    uint64_t slice = 0;
    for (int j = 0; j < 8; j++)
      slice = (slice << 8) | slices_start[i * 8 + j];
    ch->slices[i] = slice;
  }

  ch->slices_ctr = (ch->slices_ctr + SAMPLER_SLICE_BATCH) % 256;
  ch->back_state_read = true;
}

#pragma GCC optimize("O3")
static inline int32_t sampler_next(struct sampler_t *s)
{
  int32_t mixed = 0;
  bool read_one = false;
  for (int i = 0; i < SAMPLER_POLYPHONY; i++) if (s->channels[i].enabled) {
    struct sampler_channel_t *ch = &s->channels[i];
    if (ch->sample_ptr < 20 * SAMPLER_SLICE_BATCH) {
      mixed += (int32_t)ch->samples[ch->sample_ptr++] * ch->vol / 4096;
    }
    if (ch->sample_ptr >= 20 * SAMPLER_SLICE_BATCH && ch->back_state_decoded) {
      memcpy(ch->samples, ch->samples_back, sizeof ch->samples);
      ch->back_state_decoded = false;
      ch->sample_ptr = 0;
    }
    if (!read_one && !ch->back_state_read) {
      sampler_channel_read(ch);
      read_one = true;
    }
  }
  return mixed;
}

#pragma GCC optimize("O3")
// __attribute__ ((noinline))
static bool sampler_finish_decode(struct sampler_t *s)
{
  bool run = false;
  for (int i = 0; i < SAMPLER_POLYPHONY; i++) if (s->channels[i].enabled) {
    struct sampler_channel_t *ch = &s->channels[i];
    if (ch->back_state_read && !ch->back_state_decoded) {
      for (int i = 0; i < SAMPLER_SLICE_BATCH; i++)
        qoa_decode_slice(&ch->lms, ch->slices[i], ch->samples_back + 20 * i);
      if (ch->slices[i] == 0xFFFFFFFFFFFFFFFFULL) {
        for (int i = 0; i < 160; i++)
          ch->samples_back[i] = ((i / 40) % 2 == 0 ? 4096 : -4096);
      }
      // Remove read flag, set decoded
      ch->back_state_decoded = true;
      ch->back_state_read = false;
      run = true;
    }
  }
  return run;
}

static inline uint8_t sampler_trigger(struct sampler_t *s, uint32_t addr_start, uint32_t addr_end)
{
  static uint8_t timestamp = 1;
  uint8_t cur_timestamp = timestamp % 255 + 1;
  int8_t best_ch = -1;

  for (int i = 0; i < SAMPLER_POLYPHONY; i++)
    if (!s->channels[i].enabled) {
      best_ch = i;
      break;
    }

  if (best_ch == -1) {
    // Find a channel having the largest timestamp difference
    // Caveat: may induce a few mis-interrupts with the highly unlikely wraparound
    int8_t max_diff = -1;
    for (int i = 0; i < SAMPLER_POLYPHONY; i++) {
      uint8_t diff = cur_timestamp - s->channels[i].enabled;
      if (diff > max_diff) {
        max_diff = diff;
        best_ch = i;
      }
    }
  }

  struct sampler_channel_t *ch = &s->channels[best_ch];
  ch->enabled = timestamp;
  ch->vol = 256;
  ch->addr_ptr = addr_start;
  ch->addr_end = addr_end;
  ch->sample_ptr = 20 * SAMPLER_SLICE_BATCH;
  ch->back_state_read = ch->back_state_decoded = false;
  ch->slices_ctr = 0;
  timestamp = cur_timestamp;
  return best_ch;
}
